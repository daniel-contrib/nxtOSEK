var searchData=
[
  ['held',['held',['../classecrobot_1_1_p_s_p_nx.html#a1633849fa575bfba97ec26267ca6ea08',1,'ecrobot::PSPNx']]]
];

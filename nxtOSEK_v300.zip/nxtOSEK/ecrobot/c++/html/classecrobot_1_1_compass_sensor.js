var classecrobot_1_1_compass_sensor =
[
    [ "CompassSensor", "classecrobot_1_1_compass_sensor.html#a5a293125b2145c2584d79a3299f71afb", null ],
    [ "beginCalibration", "classecrobot_1_1_compass_sensor.html#a77c71740e3e25e5539f241a0013c7092", null ],
    [ "endCalibration", "classecrobot_1_1_compass_sensor.html#a4c2c81a573ac44a545c2feac52f457f4", null ],
    [ "get", "classecrobot_1_1_compass_sensor.html#a48aff95d2c93ba37871664c274082f66", null ],
    [ "getHeading", "classecrobot_1_1_compass_sensor.html#a080cad2c657331b82255369b87192471", null ]
];
var classecrobot_1_1_color_sensor =
[
    [ "ColorSensor", "classecrobot_1_1_color_sensor.html#ab07ae4ec78b8160eab0f6787e93b1024", null ],
    [ "get", "classecrobot_1_1_color_sensor.html#a1ccac9e1c0f51b023fbcf8cc9b7fde27", null ],
    [ "getColorNumber", "classecrobot_1_1_color_sensor.html#a9e35b12941ac1bb14cafc4132dd31d6b", null ],
    [ "getRawColor", "classecrobot_1_1_color_sensor.html#ab629b73bf4be0b9e148be9623d591cfb", null ]
];
var classecrobot_1_1_clock =
[
    [ "Clock", "classecrobot_1_1_clock.html#a46bc88a1b7a8610c072e08e0de73b2af", null ],
    [ "now", "classecrobot_1_1_clock.html#ae8cb5a06b4de01ceee8fadd67ee0b42a", null ],
    [ "reset", "classecrobot_1_1_clock.html#ab805a95136a65c1b90a932444a55b143", null ],
    [ "sleep", "classecrobot_1_1_clock.html#aa43ea9ef2b95b952acb61b9b0814b428", null ],
    [ "wait", "classecrobot_1_1_clock.html#a7d4ae87221588d266c32f186cf482d3a", null ]
];
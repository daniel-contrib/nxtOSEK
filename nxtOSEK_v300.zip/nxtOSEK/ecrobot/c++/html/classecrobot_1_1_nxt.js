var classecrobot_1_1_nxt =
[
    [ "eButton", "classecrobot_1_1_nxt.html#a3b26d3559801e79281d53eedff3b7512", null ],
    [ "eNxtButton", "classecrobot_1_1_nxt.html#a8613056a7e96bb8b9d36c9c8b37f91ec", null ],
    [ "Nxt", "classecrobot_1_1_nxt.html#af26e70700cce04bef606530eff3b5052", null ],
    [ "execNXTBIOS", "classecrobot_1_1_nxt.html#a21b14d072fd8b9580654613f9ad9d320", null ],
    [ "getBattMv", "classecrobot_1_1_nxt.html#abe40e99f8b70563b93b8206d3a3bf49e", null ],
    [ "getButtons", "classecrobot_1_1_nxt.html#a58da7c38187493af940630dce6b513ef", null ],
    [ "getNxtButtons", "classecrobot_1_1_nxt.html#a60926dfd8160d5d94d7a5f5cc3e9c09d", null ],
    [ "restart", "classecrobot_1_1_nxt.html#af44d9b3a024e7d335daf51b5f6802fee", null ],
    [ "shutdown", "classecrobot_1_1_nxt.html#a4476580f243f9b87ad003cc136f2b72e", null ]
];
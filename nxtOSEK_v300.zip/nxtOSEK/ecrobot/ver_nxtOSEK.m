function ret = ver_nxtOSEK()

% VER_NXTOSEK
% this info is used for only Embedded Coder Robot NXT installation.
%

ret = 3.00;

%end of file
